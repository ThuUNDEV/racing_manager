# Workshop GP — bộ asset 2D v0.1

Phong cách: concept **Workshop GP** đã chọn — nền kem, graphite, cam an toàn, garage và đường đua thể thao hiện đại. Đây là ảnh 2D mang phong cách render 3D; **không chứa mesh/model 3D**.

## Thành phần

| Nhóm | Nội dung | Định dạng |
|---|---|---|
| Đường đua | Một nền oval hoàn chỉnh, không có xe hoặc UI gắn vào ảnh | PNG RGB 1536 × 1024 |
| Xe | 8 màu: cam, graphite, trắng, xanh dương, đỏ, vàng, teal, tím | PNG RGBA atlas + 8 AtlasTexture `.tres` |
| Icon | Tiền, gem, tốc độ, vượt xe, phòng thủ, vô lăng; đội, gear, tay đua, giải, sự kiện, shop | PNG RGBA atlas + 12 AtlasTexture `.tres` |
| Tay đua | Chân dung áo cam, kèm vùng cắt avatar | PNG RGBA + AtlasTexture |
| UI | Nền app; thẻ nâng cấp; nút cam normal/hover/pressed/disabled; panel graphite; capsule; chip; tab được chọn | 10 SVG nguồn |
| Godot | Theme và 10 StyleBoxTexture để co giãn UI | `.tres` |
| Xem thử | Bố cục dọc 390 × 844, xe chạy vòng trên nền, bốn ô nâng cấp, thanh 6 mục | `.tscn` + GDScript |

Chữ, tiền, level và phần trăm được Godot hiển thị; không gắn cứng vào texture. UI dùng font mặc định Godot, không cần cài hoặc đóng gói thêm font.

## Dùng trong dự án hiện tại

Giữ nguyên thư mục `res://assets/workshop_gp/`. Các resource sử dụng đường dẫn này.

- Gán `theme.tres` vào thuộc tính Theme của UI root.
- Dùng `icons/pace.tres` hoặc các file `.tres` khác trực tiếp làm texture của TextureRect/Button.
- Gán `cars/orange.tres` vào Sprite2D. Xe nguồn hướng **xuống dưới (+Y)**: để hướng theo vector đường chạy, đặt `rotation = direction.angle() - PI/2`.
- Các xe nên được hiển thị ở cùng kích thước đích, ví dụ 11 × 21 logical px; vùng atlas đã đo theo alpha để không bị nền đen hoặc lẫn xe kế bên.
- `textures/workshop_oval.png` là nền có công trình tĩnh. Xe, marker người chơi, scoreboard và hiệu ứng vẽ riêng phía trên.
- Không đổi Main Scene hoặc gọi reset save để xem bộ asset.

## Xem riêng mà không chạm save gameplay

`preview/workshop_gp_preview.tscn` là scene lắp thử asset. Mã scene không đọc GameState hoặc RaceSim, nhưng chạy bằng project chính vẫn khởi tạo các autoload sẵn có của project.

Để xem độc lập, chạy bằng Python có sẵn:

```powershell
python assets/workshop_gp/tools/build_preview_project.py D:/WorkshopGPArtPreview
```

Sau đó mở `D:/WorkshopGPArtPreview/project.godot` trong Godot và Run. Project này không có autoload gameplay hoặc save của game chính. Có thể chọn thư mục khác; công cụ không cho đặt preview project vào trong asset pack.

Bản xem thử chỉ minh họa asset. Các nút nâng cấp thao tác trên biến tạm trong scene; không phải logic game. Thu nhập 2x/hạng xe chưa nối SDK hoặc gameplay. Thanh 6 mục giữ bố cục concept, chưa thay thanh điều hướng 5 tab của prototype hiện tại.

## Tỷ lệ, import và tái sử dụng

- Sprite/portrait/icon PNG có alpha thật. Màu nền tối xuất hiện ở một số trình xem là màu nền trình xem, không phải nền chữ nhật trong game.
- AtlasTexture trỏ vào ảnh gốc; không cần cắt lại từng PNG. `filter_clip = true` tránh lấy mẫu sang cell bên cạnh.
- Dùng lossless cho PNG; Linear filter cho icon/xe, không dùng Nearest như pixel art. Bật mipmaps khi thật sự có nhiều mức thu nhỏ và kiểm tra atlas bleeding ở kích thước nhỏ.
- StyleBoxTexture sử dụng 9-slice với margin đã chỉnh cho UI mobile. Không kéo các góc texture bằng Scale toàn node; thay đổi kích thước Control.
- Không dùng stat chip thấp hơn 20 px hoặc capsule thấp hơn 32 px vì margin sẽ ép góc.
- Manifest lưu kích thước, hash, vùng atlas và palette. `layout/workshop_oval_path.json` ghi hướng dẫn centerline theo tỷ lệ ảnh.

## Giới hạn và bước nối vào game

- Nền đường đua là một ảnh hoàn chỉnh: garage, cây, khán đài chưa phải module có thể di chuyển độc lập.
- Path trong scene là đường chạy **xem mỹ thuật**, khớp xấp xỉ với lane trên ảnh. Trước khi thay RaceView, cần ánh xạ path này sang sector/quãng đường của RaceSim; không lấy tốc độ preview làm luật thắng thua.
- Bộ asset chưa thay thế UI/gameplay hiện có và không thêm chức năng chọn chế độ lái.
- Đây là bộ art đầu tiên để tích hợp và duyệt ở kích thước thật; cần kiểm tra trên thiết bị trước khi chốt art sản phẩm.

## Dựng lại resource

Nếu đã có đầy đủ PNG trong pack, chạy:

```powershell
python assets/workshop_gp/tools/build_pack.py
```

Cần Pillow. Công cụ chỉ đọc kích thước/alpha của PNG để tạo vùng AtlasTexture, không sửa hay encode lại ảnh PNG. Các SVG nguồn có thể chỉnh trực tiếp bằng công cụ vector hoặc trong script builder.
