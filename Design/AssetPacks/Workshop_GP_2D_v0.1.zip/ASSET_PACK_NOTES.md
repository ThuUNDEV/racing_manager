# Workshop GP — Asset pack 2D v0.1

Đã dựng theo concept số 1 được chọn. Đây là bộ **2D mang phong cách 3D**, không có mesh 3D.

## File chính

- Bộ asset: `assets/workshop_gp/`
- Hướng dẫn: [README](assets/workshop_gp/README.md)
- Theme: `res://assets/workshop_gp/theme.tres`
- Scene lắp thử: `res://assets/workshop_gp/preview/workshop_gp_preview.tscn`
- Preview render thực từ Godot: [workshop_gp_assets.png](PREVIEW.png)
- Bản đóng gói: `Design/AssetPacks/Workshop_GP_2D_v0.1.zip`

## Nội dung đã có

1. Nền oval 1536 × 1024, không có xe/UI dính vào ảnh.
2. 8 xe tách nền, mỗi màu có một AtlasTexture dùng trực tiếp trong Godot.
3. 12 icon tách nền, mỗi icon có AtlasTexture riêng.
4. Chân dung tay đua áo cam và resource avatar.
5. 10 UI texture SVG, 10 StyleBoxTexture và Theme Godot.
6. Dữ liệu vùng atlas, kích thước, palette và SHA-256 trong manifest.
7. Scene xem thử theo bố cục tham chiếu: tài nguyên trên, khung đua, nâng cấp hai cột, thanh tab ở đáy.

## Đã kiểm tra

- PNG xe/icon/portrait có alpha thật; source PNG được giữ nguyên, không encode lại.
- Resource và script đã được Godot 4.7.2 import/parse trong project xem art độc lập.
- Render bằng OpenGL Compatibility trên máy hiện tại ra ảnh 390 × 844, không có lỗi runtime trong log.
- Kiểm tra trực quan và sửa margin 9-slice để capsule/chip/nút không bị ép góc ở kích thước này.
- Scene preview dùng biến tạm; không nối vào GameState hoặc RaceSim.

## Chưa thực hiện

- Chưa thay thế art/UI trong scene gameplay hiện tại.
- Chưa kiểm tra trên thiết bị Android/iOS.
- Chưa dựng vật thể 3D hoặc tách garage/cây/khán đài thành module rời.
- Đường chạy trong art preview cần được nối chính xác với sector/quãng đường của RaceSim khi tích hợp vào game.

Các thay đổi mới nằm trong asset pack và tài liệu/ảnh preview; không thay Main Scene hay cấu hình gameplay hiện có.
