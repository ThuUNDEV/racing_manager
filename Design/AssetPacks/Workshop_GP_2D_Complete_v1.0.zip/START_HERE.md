# Workshop GP — Complete 2D MVP Asset Pack 1.0

1. Giải nén vào một thư mục mới.
2. Mở `project.godot` bằng Godot 4.7.2 và Run để xem gallery độc lập.
3. Dùng menu đầu màn hình để chọn 12 màn; năm tab dưới tương ứng MVP.
4. Vào Cài đặt → Thư viện asset & âm thanh để nghe từng cue và xem VFX.

- Hướng dẫn: [assets/workshop_gp/README.md](assets/workshop_gp/README.md)
- Danh mục: [asset_catalog.json](assets/workshop_gp/asset_catalog.json)
- Phủ nội dung: [ASSET_COVERAGE.md](assets/workshop_gp/ASSET_COVERAGE.md)
- Kiểm tra: [QA.md](assets/workshop_gp/QA.md)
- Toàn bộ hình: [ASSET_CATALOG.png](Previews/ASSET_CATALOG.png)
- Các màn UI: [OVERVIEW.png](Previews/OVERVIEW.png)

Để tích hợp vào dự án đang có, sao chép thư mục `assets/workshop_gp` và nối các signal/data với gameplay của dự án đó. File project ở gói này chỉ dành cho gallery riêng. Không cần Python để sử dụng asset.

Asset 2D phong cách render 3D; không có model 3D. Các số liệu/kết quả trong gallery là minh họa duyệt UI. Xem hướng dẫn cho API card, dialog, track, audio và VFX.
